package dao;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import mapper.MemberMapper;
import vo.MemberVo;

public class MemberDao {
	private static MemberDao instance = new MemberDao(); // singleton pattern

	public static MemberDao getInstance() { // 얘로 MemberDao에 접근가능
		return instance;
	}

	private MemberDao() {
		// 생성자
	}


	public void insertGx(MemberVo vo) {
		SqlSession sqlSession = DBManager.getSqlSessionFactory().openSession(false);

		MemberMapper mapper = sqlSession.getMapper(MemberMapper.class);
		
		int num = mapper.getMemberNum(vo.getId());
		
		int rowCheck =0;
		for (String c : vo.getGxType()) {
			//System.out.println(c);
			Map<String, Object> map = new HashMap<>();
			map.put("no", num);
			map.put("gxType", c);
			rowCheck = mapper.insertGx(map);
	}
		

		if (rowCheck > 0) {
			sqlSession.commit();
		} else {
			sqlSession.rollback();
		}

		sqlSession.close();

	} // insertGx

	public void insertMem(MemberVo vo) {

		System.out.println(vo.toString());
		SqlSession sqlSession = DBManager.getSqlSessionFactory().openSession(false);

		MemberMapper mapper = sqlSession.getMapper(MemberMapper.class);

		int rowCheck = mapper.insertMem(vo);
		if (rowCheck > 0) {
			sqlSession.commit();
		} else {
			sqlSession.rollback();
		}

		sqlSession.close();
	}// insertMem

	public int userCheck(String id, String passwd) {
		int check = -1;
		SqlSession sqlSession = null;

		try {
			sqlSession = DBManager.getSqlSessionFactory().openSession(false);
			MemberMapper mapper = sqlSession.getMapper(MemberMapper.class);

			String pw = mapper.getPasswdById(id);

			if (pw != null) {
				if (pw.equals(passwd)) {
					check = 1;
				} else {
					check = 0;
				}
			} else {
				check = -1;
			}
		} finally {
			sqlSession.close();
		}
		return check;
	}
	
	public boolean IdDupCheck(String id) {
		boolean check = false; //true: 중복o, false:중복x
		SqlSession sqlSession = null;
		
		try {
			sqlSession = DBManager.getSqlSessionFactory().openSession(false);
			MemberMapper mapper = sqlSession.getMapper(MemberMapper.class);

			int dbCheck = mapper.getCheckIdDup(id);
			System.out.println("dao_dbCheck:"+ dbCheck);
			if(dbCheck == 1) {
				check = true; //dup
			} else {
				check = false;
			}
		} finally {
			sqlSession.close();
		}
		//System.out.println(check);
		return check;
	}
	

//	public static void main(String[] args) {
//
//	}
}
