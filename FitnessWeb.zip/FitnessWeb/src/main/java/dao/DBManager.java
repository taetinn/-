package dao;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class DBManager {
	
	private static SqlSessionFactory sqlSessionFactory; //한번만 받아오도록
	
	static {
		System.out.println("전역처리");
		try(InputStream is = Resources.getResourceAsStream("mybatis-config.xml")){
			System.out.println("전역처리2");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(is);
			System.out.println("전역처리3");

		} catch (IOException e) {
			System.out.println("전역처리 er");

			e.printStackTrace();
		}
		System.out.println("qwe");
	}
	
	public static SqlSessionFactory getSqlSessionFactory() {
		System.out.println("sf 정상처리");
		return sqlSessionFactory;
	}
}
