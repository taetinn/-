package mapper;

import java.util.Map;

import org.apache.ibatis.annotations.Select;

import vo.MemberVo;

public interface MemberMapper {

	
	int insertMem(MemberVo vo);
	
	int insertGx(Map<String, Object> map);
	
	@Select("select passwd from member where id=#{id}")
	String getPasswdById(String id);
	
	@Select("select count(*) from member where id=#{id}")
	int getCheckIdDup(String id);
	
	@Select("select no from member where id=#{id}")
	int getMemberNum(String id);
}
