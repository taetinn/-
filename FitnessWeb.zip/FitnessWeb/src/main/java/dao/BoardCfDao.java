package dao;

public class BoardCfDao {
	private static BoardCfDao instance = new BoardCfDao();
	
	public static BoardCfDao getInstance() {
		return instance;
	}
	public static void main(String[] args) {

	}

}
